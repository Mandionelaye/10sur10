module.exports=[35447,a=>{a.v("/_next/static/media/icon.d5b0f2b0.svg")},68991,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(35447).default,width:842,height:595}}];

//# sourceMappingURL=Documents_Jangalma_10sur10_app_10sur10_app_f2693acb._.js.map