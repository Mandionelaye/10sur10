globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/d61b6d4abe1e28a2.js",
      "static/chunks/5cd81d2a227403c4.js",
      "static/chunks/turbopack-7964ca83be8462da.js"
    ],
    "/_error": [
      "static/chunks/65a06fbab337f54b.js",
      "static/chunks/5cd81d2a227403c4.js",
      "static/chunks/turbopack-dd04ead381f1fc64.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/2ac46e8255a5b5b4.js",
    "static/chunks/61694acc080c7261.js",
    "static/chunks/6ef53aaa1962c5b3.js",
    "static/chunks/dc7a8a78e94915fd.js",
    "static/chunks/turbopack-a67b08b5b875d800.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];