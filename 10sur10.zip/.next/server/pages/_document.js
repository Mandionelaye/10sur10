var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__2f2fc7d2._.js")
R.c("server/chunks/ssr/[root-of-the-server]__aa49299e._.js")
R.m(9030)
module.exports=R.m(9030).exports
