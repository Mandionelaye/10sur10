var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__c057c6c5._.js")
R.c("server/chunks/d9c71_next_dist_e1da74e9._.js")
R.c("server/chunks/[root-of-the-server]__e13cbb05._.js")
R.c("server/chunks/d9c71_next_dist_14e03c79._.js")
R.m(87157)
R.m(16663)
module.exports=R.m(16663).exports
