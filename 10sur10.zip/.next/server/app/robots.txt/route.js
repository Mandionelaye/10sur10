var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__2ff528e9._.js")
R.c("server/chunks/d9c71_next_dist_e1da74e9._.js")
R.c("server/chunks/[root-of-the-server]__e13cbb05._.js")
R.c("server/chunks/d9c71_next_dist_14e03c79._.js")
R.m(48835)
R.m(66153)
module.exports=R.m(66153).exports
