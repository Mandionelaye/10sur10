__turbopack_load_page_chunks__("/_app", [
  "static/chunks/d61b6d4abe1e28a2.js",
  "static/chunks/5cd81d2a227403c4.js",
  "static/chunks/turbopack-7964ca83be8462da.js"
])
