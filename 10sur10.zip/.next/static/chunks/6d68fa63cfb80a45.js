__turbopack_load_page_chunks__("/_error", [
  "static/chunks/65a06fbab337f54b.js",
  "static/chunks/5cd81d2a227403c4.js",
  "static/chunks/turbopack-dd04ead381f1fc64.js"
])
