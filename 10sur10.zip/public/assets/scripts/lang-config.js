window.__GOOGLE_TRANSLATION_CONFIG__ = {
  languages: [
    { title: "Fr", name: "fr", img:'https://flagcdn.com/w320/fr.png' },
    { title: "En", name: "en",  img:'https://flagcdn.com/w320/us.png' },
    { title: "Ar", name: "ar",  img:'https://flagcdn.com/w320/mr.png' },
  ],
  defaultLanguage: "fr",
};