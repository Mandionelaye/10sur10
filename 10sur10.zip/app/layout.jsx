import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import Headers from "@/libs/components/headers";
import Footer from "@/libs/components/Footer";
import Script from "next/script";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata = {
  metadataBase: new URL("https://10sur10.net"),
  keywords: [
  "10sur10",
  "10sur10.net",
  "cours a domicile",
  "cours particuliers à domicile",
  "soutien scolaire",
  "soutient scolaire",
  "soutien scolaire à domicile",
  "cours de soutien scolaires",
  "aide aux devoirs",
  "aide scolaire en ligne",
  "soutien scolaire en ligne",
  "suivi scolaire personnalisé",
  "soutien scolaire primaire",
  "cours particuliers élémentaire",
  "aide aux devoirs élémentaire",
  "soutien scolaire collège",
  "cours particulier collège toutes matières",
  "soutien scolaire lycée",
  "tutorat lycée",
  "préparation brevet",
  "préparation bac",
  "cours de mathématiques collège",
  "cours de mathématiques lycée",
  "cours de français collège",
  "cours de français lycée",
  "cours de sciences physique chimie",
  "cours de SVT",
  "cours d’anglais soutien scolaire",
  "cours d’histoire géographie",
  "aide en philosophie lycée",
  "soutien scolaire Dakar",
  "cours particuliers Dakar",
  "soutien scolaire Sénégal",
  "cours à domicile Dakar",
  "aide scolaire près de chez moi",
  "réussir le brevet avec soutien scolaire",
  "aide devoirs maths collège à domicile",
  "cours particuliers français lycée Dakar",
  "soutien scolaire en ligne pour élèves en difficulté",
  "prof à domicile toutes matières Sénégal",
  "soutien scolaire personnalisé pour bac S",
  "soutien scolaire personnalisé pour bac L",
  "soutien scolaire personnalisé pour bac ES"
],
  title:{
    default: "10sur10 - Soutien scolaire et cours particuliers à domicile pour élèves du primaire, collège et lycée en Afrique",
    template: "%s | 10sur10",
  },
  openGraph: {
    type: "website",
    locale: "fr_FR",
    url: "https://10sur10.net",
    title: "10sur10 - Soutien scolaire et cours particuliers à domicile pour élèves du primaire, collège et lycée en Afrique",
    description: "10sur10.net propose un accompagnement scolaire personnalisé : soutien scolaire, aide aux devoirs et cours particuliers à domicile pour élèves du primaire, collège et lycée en Afrique. Des professeurs qualifiés pour toutes les matières (maths, français, sciences, anglais, etc.) afin d’assurer la réussite scolaire.",
    siteName: "10sur10",
    images: [
      {
        url: "https://10sur10.net/assets/logo/logo.png",
        width: 800,
        height: 600,
        alt: "10sur10",
      },
    ],
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="fr">
       <head>
        {/* Script Google Analytics */}
        <Script
          src={`https://www.googletagmanager.com/gtag/js?id=G-N4CX8X97LP`}
          strategy="afterInteractive"
        />
        <Script id="google-analytics" strategy="afterInteractive">
          {`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-N4CX8X97LP');
          `}
        </Script>
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <Headers />
        <div id="google_translate_element" style={{ display: "none" }}></div>
          <div className="min-h-screen bg-white">
            {children}
          </div>
        <Footer />

        <Script
          src="/assets/scripts/lang-config.js"
          strategy="beforeInteractive"
        />
        <Script
          src="/assets/scripts/translation.js"
          strategy="beforeInteractive"
        />
        <Script
          src="//translate.google.com/translate_a/element.js?cb=TranslateInit"
          strategy="afterInteractive"
        />
      </body>
    </html>
  );
}
